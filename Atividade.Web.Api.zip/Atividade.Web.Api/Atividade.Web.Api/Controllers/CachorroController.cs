using Atividade.Web.Api.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Atividade.Web.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CachorroController : ControllerBase
    {
        private static List<Cachorro> _cachorros = new List<Cachorro>();

        [HttpPost]
        public IActionResult CreateCachorro([FromBody] CachorroDto dto)
        {
            try
            {
                ValidateDto(dto);

                var porte = NormalizeAndValidatePorte(dto.Porte);
                var cachorro = Cachorro.Create(dto.Raca, porte);
                _cachorros.Add(cachorro);
                return CreatedAtAction(nameof(GetCachorroById), new { id = cachorro.Id }, new { Id = cachorro.Id, Raca = cachorro.Raca, Porte = cachorro.Porte.ToString() });
            }
            catch (ArgumentNullException ex)
            {
                return BadRequest("O objeto DTO n�o pode ser nulo. Por favor, forne�a os dados completos do cachorro.");
            }
            catch (ArgumentException ex)
            {
                return BadRequest("Dados inv�lidos fornecidos: " + ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocorreu um erro inesperado no servidor. Por favor, tente novamente mais tarde.");
            }
        }

        [HttpPost("{id}")]
        public IActionResult UpdateCachorro(string id, [FromBody] CachorroDto dto)
        {
            try
            {
                if (!Guid.TryParse(id, out var guidId))
                {
                    return BadRequest("O ID fornecido n�o � v�lido. Por favor, forne�a um ID v�lido no formato GUID.");
                }

                var existingCachorro = _cachorros.FirstOrDefault(c => c.Id == guidId);
                if (existingCachorro == null)
                {
                    return NotFound("N�o foi poss�vel encontrar um cachorro com o ID fornecido.");
                }

                ValidateDto(dto);
                var porte = NormalizeAndValidatePorte(dto.Porte);
                existingCachorro.Update(dto.Raca, porte);
                return Ok(new { Id = existingCachorro.Id, Raca = existingCachorro.Raca, Porte = existingCachorro.Porte.ToString() });
            }
            catch (ArgumentNullException ex)
            {
                return BadRequest("O objeto DTO n�o pode ser nulo. Por favor, forne�a os dados completos do cachorro.");
            }
            catch (ArgumentException ex)
            {
                return BadRequest("Dados inv�lidos fornecidos: " + ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocorreu um erro inesperado no servidor. Por favor, tente novamente mais tarde.");
            }
        }

        [HttpGet]
        public IActionResult GetCachorros()
        {
            return Ok(_cachorros.Select(c => new { Id = c.Id, Raca = c.Raca, Porte = c.Porte.ToString() }));
        }

        [HttpGet("{id}")]
        public IActionResult GetCachorroById(string id)
        {
            try
            {
                if (!Guid.TryParse(id, out var guidId))
                {
                    return BadRequest("O ID fornecido n�o � v�lido. Por favor, forne�a um ID v�lido no formato GUID.");
                }

                var cachorro = _cachorros.FirstOrDefault(c => c.Id == guidId);
                if (cachorro == null)
                {
                    return NotFound("N�o foi poss�vel encontrar um cachorro com o ID fornecido.");
                }

                return Ok(new { Id = cachorro.Id, Raca = cachorro.Raca, Porte = cachorro.Porte.ToString() });
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Ocorreu um erro inesperado no servidor. Por favor, tente novamente mais tarde.");
            }
        }

        [HttpDelete]
        public IActionResult DeleteAllCachorros()
        {
            _cachorros.Clear();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteCachorroById(string id)
        {
            if (!Guid.TryParse(id, out var guidId))
            {
                return BadRequest("O ID fornecido n�o � v�lido. Por favor, forne�a um ID v�lido no formato GUID.");
            }

            var cachorro = _cachorros.FirstOrDefault(c => c.Id == guidId);
            if (cachorro == null)
            {
                return NotFound("N�o foi poss�vel encontrar um cachorro com o ID fornecido.");
            }

            _cachorros.Remove(cachorro);
            return NoContent();
        }

        private void ValidateDto(CachorroDto dto)
        {
            // Verifica��o do tipo e validade do campo 'Raca'
            if (dto.Raca == null)
            {
                throw new ArgumentException("O campo 'Raca' � obrigat�rio. Por favor, forne�a o valor da ra�a.");
            }
            if (dto.Raca.GetType() != typeof(string))
            {
                throw new ArgumentException("O campo 'Raca' deve ser uma string. Por favor, forne�a um valor v�lido.");
            }
            if (string.IsNullOrWhiteSpace(dto.Raca))
            {
                throw new ArgumentException("O campo 'Raca' n�o pode ser vazio. Por favor, forne�a um valor v�lido.");
            }

            // Verifica��o do tipo e validade do campo 'Porte'
            if (dto.Porte == null)
            {
                throw new ArgumentException("O campo 'Porte' � obrigat�rio. Por favor, forne�a o valor do porte.");
            }
            if (dto.Porte.GetType() != typeof(string))
            {
                throw new ArgumentException("O campo 'Porte' deve ser uma string. Por favor, forne�a um valor v�lido.");
            }
            if (string.IsNullOrWhiteSpace(dto.Porte))
            {
                throw new ArgumentException("O campo 'Porte' n�o pode ser vazio. Por favor, forne�a um valor v�lido.");
            }
        }

        private string NormalizeAndValidatePorte(string porteInput)
        {
            var normalizedPorte = RemoveAccents(porteInput);
            normalizedPorte = normalizedPorte.ToUpper();

            if (!Enum.TryParse(typeof(Porte), normalizedPorte, true, out var parsedPorte))
            {
                throw new ArgumentException("Porte inv�lido. O valor fornecido n�o corresponde a um porte v�lido.", nameof(porteInput));
            }

            return normalizedPorte;
        }

        private string RemoveAccents(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return input;

            string normalizedString = input.Normalize(NormalizationForm.FormD);
            Regex regex = new Regex("\\p{IsCombiningDiacriticalMarks}+");
            return regex.Replace(normalizedString, string.Empty).Normalize(NormalizationForm.FormC);
        }
    }

    public class CachorroDto
    {
        public string Raca { get; set; }
        public string Porte { get; set; }
    }

    // Defini��o de exce��es personalizadas.
    public class ResourceNotFoundException : Exception
    {
        public ResourceNotFoundException(string message) : base(message) { }
    }
}