﻿using System;

namespace Atividade.Web.Api.Models
{
    public class Cachorro
    {
        public Guid Id { get; private set; }
        public string Raca { get; private set; }
        public Porte Porte { get; private set; }


        private Cachorro(Guid id, string raca, Porte porte)
        {
            this.Id = id;
            this.Raca = raca;
            this.Porte = porte;
        }

        public static Cachorro Create(string raca, string porte)
        {
            if (string.IsNullOrEmpty(raca))
            {
                throw new ArgumentException("Raça não pode ser nula ou vazia.", nameof(raca));
            }

            Porte porteEnum;
            if (!Enum.TryParse(porte, true, out porteEnum))
            {
                throw new ArgumentException("Porte inválido.", nameof(porte));
            }

            return new Cachorro(Guid.NewGuid(), raca, porteEnum);
        }

        public void Update(string raca, string porte)
        {
            if (string.IsNullOrEmpty(raca))
            {
                throw new ArgumentException("Raça não pode ser nula ou vazia.", nameof(raca));
            }

            Porte porteEnum;
            if (!Enum.TryParse(porte, true, out porteEnum))
            {
                throw new ArgumentException("Porte inválido.", nameof(porte));
            }

            this.Raca = raca;
            this.Porte = porteEnum;
        }
    }

    public enum Porte
    {
        PEQUENO,
        MEDIO,
        GRANDE
    }
}
